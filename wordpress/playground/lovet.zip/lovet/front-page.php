<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>LOVET | Arena perlada para gatos</title>
  <meta name="description" content="LOVET Super Premium, arena perlada aglomerante con aroma a aloe vera, en bolsas de 5, 10 y 20 kg. Encuentra tu punto de venta más cercano.">
  <meta name="theme-color" content="#00433c">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?> data-tone="dark">
<?php wp_body_open(); ?>
  <a class="skip" href="#donde">Saltar a dónde comprar</a>

  <header class="topbar">
    <a class="topbar__logo" href="#inicio" aria-label="LOVET, volver al inicio">
      <img class="logo-light" src="<?php echo esc_url( get_theme_file_uri( 'assets/logo-wordmark.png' ) ); ?>" alt="" width="1200" height="391">
      <img class="logo-dark" src="<?php echo esc_url( get_theme_file_uri( 'assets/logo-wordmark-aloe.png' ) ); ?>" alt="" width="1200" height="391">
    </a>
    <a class="topbar__cta" href="#donde">Dónde comprar</a>
  </header>

  <nav class="rail" aria-label="Secciones de la página">
    <a href="#inicio"><span>Inicio</span></a>
    <a href="#familia"><span>Por qué LOVET</span></a>
    <a href="#tocala"><span>Pruébala</span></a>
    <a href="#cambio"><span>El cambio</span></a>
    <a href="#donde"><span>Dónde comprar</span></a>
    <a href="#contacto"><span>Contacto</span></a>
  </nav>
  <div class="progress" aria-hidden="true"><span id="progress-bar"></span></div>

  <main>

    <!-- 1. PORTADA -->
    <section class="page" id="inicio" data-tone="dark" aria-labelledby="t-inicio">
      <div class="page__inner hero">
        <div class="hero__copy">
          <h1 class="display" id="t-inicio" lang="en">If you LOVET, they LOVET</h1>
          <p class="hero__lead">Arena perlada super premium con aroma a aloe vera.</p>
          <p class="hero__text">Libre de polvo, control de malos olores y aglomeración firme.</p>
          <div class="hero__actions">
            <a class="btn btn--yellow" href="#donde">Dónde comprar</a>
            <a class="btn btn--line" href="#contacto">Escríbenos</a>
          </div>
          <button class="peek-btn" id="bag-toggle" type="button" aria-pressed="false" aria-controls="bag">Mirar dentro de la bolsa</button>
        </div>

        <figure class="bag" id="bag">
          <canvas class="bag__inside" id="bag-pearls" aria-hidden="true"></canvas>
          <img class="bag__skin" id="bag-img" src="<?php echo esc_url( get_theme_file_uri( 'assets/bolsa-10kg.png' ) ); ?>" width="467" height="683"
               alt="Bolsa de 10 kg de LOVET Premium Clumping Cat Litter">
        </figure>
      </div>
    </section>

    <!-- 2. POR QUE LOVET -->
    <section class="page" id="familia" data-tone="light" aria-labelledby="t-familia">
      <div class="page__inner family">
        <div class="family__photo">
          <img src="<?php echo esc_url( get_theme_file_uri( 'assets/familia.jpg' ) ); ?>"
               alt="Una persona vierte arena LOVET de la bolsa de 5 kg en la caja mientras un gato naranja la mira" width="972" height="1215">
        </div>
        <div class="family__text">
          <h2 class="family__title" id="t-familia">¿Por qué LOVET?</h2>
          <p class="family__lead">Amor que se nota. Cuidado que se siente.</p>
          <p>LOVET junta dos palabras: el amor con el que lo cuidas y el respaldo veterinario que merece. Una arena pensada como la piensa un veterinario y elegida como la elige alguien que quiere.</p>
          <dl class="naming">
            <div>
              <dt>Love</dt>
              <dd>Amor, afecto y el vínculo que no se negocia.</dd>
            </div>
            <div>
              <dt>Vet</dt>
              <dd>Respaldo, salud y cuidado profesional en cada detalle.</dd>
            </div>
          </dl>
        </div>
      </div>
    </section>

    <!-- 3. PRUEBALA -->
    <section class="page" id="tocala" data-tone="dark" aria-labelledby="t-tocala">
      <canvas class="field" id="field" aria-hidden="true"></canvas>
      <div class="page__inner field-ui">
        <div class="field-ui__copy">
          <h2 class="display" id="t-tocala">Toca la arena.</h2>
          <p>Sus perlas absorben el líquido y aglomeran firmemente para que puedas retirarla fácilmente con la pala.</p>
          <button class="btn btn--line" id="field-btn" type="button">Pruébalo aquí</button>
        </div>
        <div class="field-ui__bottom">
          <!-- los mismos beneficios que lleva la bolsa -->
          <ul class="perks">
            <li>
              <svg viewBox="0 0 24 24" aria-hidden="true"><path fill-rule="evenodd" d="M12 1.5a10.5 10.5 0 1 1 0 21 10.5 10.5 0 0 1 0-21zM10.8 5.5h2.4v6.3h-2.4zM13.2 11.8h4v2.4h-6.4v-2.4z"/></svg>
              Mayor duración
            </li>
            <li>
              <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2" y="1.5" width="9.2" height="8" rx="1.6"/><rect x="12.8" y="1.5" width="9.2" height="8" rx="1.6"/><path d="M2 11.2h20v.6a10 10 0 0 1-20 0z"/></svg>
              100% natural
            </li>
            <li>
              <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="8.6" cy="8.4" r="6.6"/><circle cx="16.6" cy="10.6" r="5.6"/><circle cx="10.6" cy="17.4" r="5.4"/></svg>
              Aglomeración firme
            </li>
            <li>
              <svg viewBox="0 0 24 24" aria-hidden="true"><ellipse cx="12" cy="16.6" rx="6.2" ry="5.2"/><ellipse cx="4.2" cy="10.2" rx="2.4" ry="3"/><ellipse cx="8.8" cy="5.6" rx="2.5" ry="3.2"/><ellipse cx="15.2" cy="5.6" rx="2.5" ry="3.2"/><ellipse cx="19.8" cy="10.2" rx="2.4" ry="3"/></svg>
              99% libre de polvo
            </li>
            <li>
              <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M5 2c-2.4 3.3 2.4 6.7 0 10s2.4 6.7 0 10M12 2c-2.4 3.3 2.4 6.7 0 10s2.4 6.7 0 10M19 2c-2.4 3.3 2.4 6.7 0 10s2.4 6.7 0 10"/></svg>
              Control de olores
            </li>
            <li>
              <svg viewBox="0 0 24 24" aria-hidden="true"><mask id="perk-x"><rect width="24" height="24" fill="#fff"/><path d="M7.2 7.2l9.6 9.6M16.8 7.2l-9.6 9.6" stroke="#000" stroke-width="2.2" stroke-linecap="round"/></mask><path mask="url(#perk-x)" d="M7 1.5c1.9 0 3.5 1 5 2.6 1.5-1.6 3.1-2.6 5-2.6a5.5 5.5 0 0 1 5.5 5.5c0 1.9-1 3.5-2.6 5 1.6 1.5 2.6 3.1 2.6 5a5.5 5.5 0 0 1-5.5 5.5c-1.9 0-3.5-1-5-2.6-1.5 1.6-3.1 2.6-5 2.6A5.5 5.5 0 0 1 1.5 17c0-1.9 1-3.5 2.6-5C2.5 10.5 1.5 8.9 1.5 7A5.5 5.5 0 0 1 7 1.5z"/></svg>
              Absorción rápida
            </li>
          </ul>
          </div>
      </div>
    </section>

    <!-- 4. EL CAMBIO -->
    <section class="page" id="cambio" data-tone="dark" aria-labelledby="t-cambio">
      <div class="page__inner switch">
        <div class="switch__text">
          <h2 class="display" id="t-cambio">Una nueva arena, paso a paso.</h2>
          <p class="switch__intro">Dale tiempo a tu gato para descubrir LOVET. Mezcla un poco de nuestra arena con la que usa habitualmente y aumenta la cantidad progresivamente, según cómo se adapte.</p>

          <div class="steps" role="tablist" aria-label="Pasos del cambio">
            <button type="button" role="tab" id="step-0" aria-controls="mix-panel" aria-selected="true">
              <span class="steps__n">1</span>
              <span class="steps__title">Empieza poco a poco</span>
              <span class="steps__text">Añade una pequeña cantidad de LOVET a su arena habitual.</span>
            </button>
            <button type="button" role="tab" id="step-1" aria-controls="mix-panel" aria-selected="false" tabindex="-1">
              <span class="steps__n">2</span>
              <span class="steps__title">Aumenta la mezcla</span>
              <span class="steps__text">Incorpora más LOVET gradualmente si tu gato la acepta.</span>
            </button>
            <button type="button" role="tab" id="step-2" aria-controls="mix-panel" aria-selected="false" tabindex="-1">
              <span class="steps__n">3</span>
              <span class="steps__title">Observa su adaptación</span>
              <span class="steps__text">Continúa hasta usar solo LOVET, sin apresurar el proceso.</span>
            </button>
          </div>
          <p class="switch__after">Tu michi tiene su propio ritmo.</p>
        </div>

        <figure class="switch__box" id="mix-panel" role="tabpanel" aria-labelledby="step-0">
          <canvas id="mix-box" role="img" aria-label="Caja de arena con un poco de LOVET mezclado con su arena habitual."></canvas>
          <figcaption class="switch__note">*Imagen referencial</figcaption>
        </figure>

        <figure class="switch__bags">
          <img src="<?php echo esc_url( get_theme_file_uri( 'assets/bolsas-presentaciones.webp' ) ); ?>" alt="Bolsas de arena LOVET Premium Clumping Cat Litter de 5 kg, 10 kg y 20 kg" width="1433" height="794" loading="lazy">
        </figure>
      </div>
    </section>

    <!-- 5. DONDE COMPRAR: MAPA -->
    <section class="page" id="donde" data-tone="light" aria-labelledby="t-donde">
      <div class="map" id="map" role="region" aria-label="Mapa de puntos de venta de LOVET en Lima"></div>
      <div class="page__inner stores-wrap">
        <aside class="stores">
          <div class="stores__head">
            <h2 id="t-donde">Encuéntranos en</h2>
            <span class="stores__demo">Datos de ejemplo</span>
          </div>
          <div class="stores__search">
            <label class="sr-only" for="store-q">Buscar por distrito, tienda o calle</label>
            <input id="store-q" type="search" placeholder="Distrito, tienda o calle" autocomplete="off">
            <button class="btn btn--aloe btn--sm" id="near-me" type="button">Cerca de mí</button>
          </div>
          <p class="stores__count" id="store-count" aria-live="polite"></p>
          <div class="stores__list" id="store-list"></div>
        </aside>
      </div>
    </section>

    <!-- 6. CONTACTO -->
    <section class="page" id="contacto" data-tone="dark" aria-labelledby="t-contacto">
      <div class="page__inner contact">
        <div class="contact__intro">
          <h2 class="display" id="t-contacto">Hablemos.</h2>
          <p>Si tienes una veterinaria, un pet shop o una tienda online y te interesa LOVET, escríbenos. También atendemos pedidos por correo.</p>
          <div class="contact__mail">
            <a class="btn btn--yellow" href="mailto:marketingpets@solvet.com.pe?subject=Hola%20LOVET">Escribir por correo</a>
            <a class="contact__address" href="mailto:marketingpets@solvet.com.pe">marketingpets@solvet.com.pe</a>
          </div>
          <div class="contact__photo">
            <img src="<?php echo esc_url( get_theme_file_uri( 'assets/contacto-gatos.jpg' ) ); ?>" alt="Tres gatos sentados uno al lado del otro mirando hacia arriba sobre un fondo amarillo: uno crema de pelo largo, uno atigrado naranja y uno atigrado gris" width="1264" height="848" loading="lazy">
          </div>
        </div>

        <div class="contact__box">
          <form class="contact-form" id="contact-form" novalidate>
            <div class="field">
              <label for="c-name">Nombre completo</label>
              <input id="c-name" name="nombre" autocomplete="name" required aria-describedby="c-name-err">
              <p class="field__error" id="c-name-err"></p>
            </div>
            <div class="field">
              <label for="c-biz">Nombre comercial</label>
              <input id="c-biz" name="nombre_comercial" autocomplete="organization">
            </div>
            <div class="field">
              <label for="c-mail">Correo</label>
              <input id="c-mail" name="correo" type="email" autocomplete="email" placeholder="nombre@correo.com" required aria-describedby="c-mail-err">
              <p class="field__error" id="c-mail-err"></p>
            </div>
            <div class="field">
              <label for="c-phone">Número</label>
              <input id="c-phone" name="numero" type="tel" autocomplete="tel" placeholder="987 654 321" aria-describedby="c-phone-err">
              <p class="field__error" id="c-phone-err"></p>
            </div>
            <div class="field">
              <label for="c-place">Distrito / Provincia</label>
              <input id="c-place" name="distrito_provincia" autocomplete="address-level2">
            </div>
            <div class="field">
              <label for="c-ruc">RUC</label>
              <input id="c-ruc" name="ruc" inputmode="numeric" maxlength="11" placeholder="20123456789" aria-describedby="c-ruc-err">
              <p class="field__error" id="c-ruc-err"></p>
            </div>
            <div class="field field--wide">
              <label for="c-who">¿Quién nos escribe?</label>
              <select id="c-who" name="perfil">
                <option>Tengo una veterinaria</option>
                <option>Tengo un pet shop</option>
                <option>Tengo una tienda online</option>
                <option>Otro</option>
              </select>
            </div>
            <div class="field field--wide">
              <label for="c-msg">Mensaje</label>
              <textarea id="c-msg" name="mensaje" rows="3" required aria-describedby="c-msg-err"></textarea>
              <p class="field__error" id="c-msg-err"></p>
            </div>
            <div class="contact-form__foot field--wide">
              <button class="btn btn--aloe" type="submit">Enviar mensaje</button>
            </div>
          </form>
          <div class="contact-done" id="contact-done" hidden tabindex="-1">
            <h3>Tu mensaje está listo.</h3>
            <p id="contact-done-text"></p>
            <button class="btn btn--outline" id="contact-again" type="button">Enviar otro mensaje</button>
          </div>
        </div>

        <footer class="footer">
          <img src="<?php echo esc_url( get_theme_file_uri( 'assets/logo-wordmark.png' ) ); ?>" alt="LOVET" width="1200" height="391" loading="lazy">
          <ul class="footer__links">
            <li><a href="#">Instagram</a></li>
            <li><a href="#">Facebook</a></li>
            <li><a href="#">TikTok</a></li>
          </ul>
          <p>© 2026 LOVET</p>
        </footer>
      </div>
    </section>
  </main>

<?php wp_footer(); ?>
</body>
</html>
